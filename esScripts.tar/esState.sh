#!/bin/bash
curl -u admin:vmfhwprxmspffh2 -XGET '10.96.250.211:10200/_cluster/state?pretty&filter_indices&filter_blocks&filter_nodes&filter_metadata' | node esState.js

