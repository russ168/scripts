//# !/usr/bin /env node
var fs = require( 'fs');
//var file = __dirname + '/test.json';
var db = require('../utils/db.js');

global.projects = [];

getProjects = function(cb) {
	var sql = "select projectname from project";
	db.query(sql, cb);
};

addProjects = function(result, fields) {
	var json = {};
	for ( var i = 0, len = result.length; i < len; i++) {
		global.projects.push(row.projectname);
};

getMapping = function(opts) {
	//var url = "http://" + opts.host + ":" + opts.port;
	var path = "";
	if(opts.indices) {
		path = path + "/" + opts.indices;
		if(opts.types) {
			path = path + "/" + opts.types;
		}
	}
	path = path + "/_mapping";
	http.get({
		host : opts.host,
		port : opts.port,
		path : encodeURI(path),
		auth : SEARCH_CONFIG.user + ":" + SEARCH_CONFIG.password
	}, function(resp) {
		var result = [];
		resp.setEncoding('utf-8');
		resp.on("data", function(rs) {
			result.push(rs);
		});
		resp.on("end", function(rs) {
			try {
				if(rs) {
					result.push(rs);
				}
				var rsObj = JSON.parse(result.join(""));
				$.execFunc(opts.success, rsObj);
			} catch (e) {
				e.message += " ; " + path;
				$.execFunc(opts.error, e);
			}
		});
	}).on("error", function(e) {
		e.message += " ; " + path;
		$.execFunc(opts.error, e);
	});
};

function getMapping() {
	for(project in projects)
	http.get({
		host : host,
		port : port,
		path : encodeURI("/_cluster/state/"),
		auth : SEARCH_CONFIG.user + ":" + SEARCH_CONFIG.password
	}, function(resp) {
		var result = [];
		resp.setEncoding('utf-8');
		resp.on("data", function(rs) {
			result.push(rs);
		});
		resp.on("end", function(rs) {
			try {
				if(rs) {
					result.push(rs);
				}

				var rsObj = JSON.parse(result.join(""));
				if(!!rsObj.error) {
					$.execFunc(error, {
						esError : true,
						reqInfo : reqInfo,
						message : rsObj
					});
				} else {
					$.execFunc(success, rsObj);
				}
			} catch (e) {
				e.message += " ; " + "get cluster state error!";
				logger.error("get cluster state error!");
			}
		});
	}).on("error", function(e) {
		e.message += " ; " + "get cluster state error!";
		logger.error("get cluster state error!");
	});
	
}

function parseMapping() {
       //console.log("json is:" + JSON.stringify(json));
       
       var result = [];
       var nodes = json.nodes;
       var reg = /inet\[.*\/(.*):9300\]/ ;
       
       var indices = json.metadata.indices;
       
       for(var index in indices) {
             var node = nodes[nodeName];         
             //console.log("node is:" + JSON.stringify(node));           
             var res = {};
             //name
            res.name = node.name;
             //console.log("transport address is:" + node.transport_address);      
             var list = reg.exec(node.transport_address);
             //console.log("transport address is:" + list);
            res.ip = list[1 ];

             //size
            res.indices_size = node.indices.store.size;
            res.docs = node.indices.docs.count;

             //mem
            res.heap_committed = node.jvm.mem.heap_committed;
            res.heap_used = node.jvm.mem.heap_used;
            res.mem_used_percent = node.jvm.mem.heap_used_in_bytes /node.jvm.mem.heap_committed_in_bytes;
            res.field_cache = node.indices.cache.field_size;
            res.field_cache_percent = node.indices.cache.field_size_in_bytes /node.jvm.mem.heap_committed_in_bytes;
            res.filter_cache = node.indices.cache.filter_size;
            res.filter_cache_percent = node.indices.cache.filter_size_in_bytes /node.jvm.mem.heap_committed_in_bytes;

             //cpu
            res.cpu_used_percent = node.process.cpu.percent;

             //file handles
            res.files = node.process.open_file_descriptors;

            result.push(res);
      }
       return result;
};

if (process.argv[2] == "-f") {
       var file = process.argv[3];
      fs.readFile(file, 'utf8', function (err, data) {
             if(err) {
                  console .log('Error: ' + err);
                   return;
            }
            json = JSON.parse(data);
            result = parseStats(json);
            console.dir(result);
             return;
      });
}

var input = [];
process.stdin.resume();
process.stdin.setEncoding( 'utf8');

process.stdin.on( 'data', function (chunk) {
  process.stdout.write( 'data: ' + chunk);
  input.push(chunk);
});

process.stdin.on( 'end', function (chunk) {
  process.stdout.write( 'end');
  input.push(chunk);
  var json = JSON.parse(input.join( ""));
  result = parseStats(json);
  console.dir(result);
});
