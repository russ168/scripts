#!/bin/bash
curl -u admin:vmfhwprxmspffh2 -XGET 10.96.250.215:10200/_nodes?pretty=true

