#!/bin/bash
curl -u admin:vmfhwprxmspffh2 -XGET 10.96.250.214:10200/_nodes/stats?all=true|node esStats.js

